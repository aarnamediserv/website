'use strict';
const test = require('node:test'), assert = require('node:assert');
const crypto = require('crypto');
const P = require('../lib/payments');
const { makeHandlers } = require('../lib/handlers');

const UID = 'A'.repeat(28);
test('parseRupeesToPaise accepts normal totals and rejects odd ones', () => {
  assert.equal(P.parseRupeesToPaise('₹1,499'), 149900);
  assert.equal(P.parseRupeesToPaise('Rs 2250/-'), 225000);
  assert.equal(P.parseRupeesToPaise('₹2,250.5'), 225050);
  assert.equal(P.parseRupeesToPaise('1499.75'), 149975);
  assert.equal(P.parseRupeesToPaise('₹12,34,567'), null);          // above the cap
  for (const bad of ['', 'free', '₹0', '₹-5', '1,499 + 100', '₹1.499,00', null, undefined, 12, '₹99999999999999999999']) assert.equal(P.parseRupeesToPaise(bad), null, String(bad));
});
test('signature check', () => {
  const body = Buffer.from('{"a":1}'), sig = crypto.createHmac('sha256', 's3cret').update(body).digest('hex');
  assert.equal(P.verifyWebhookSignature(body, sig, 's3cret'), true);
  assert.equal(P.verifyWebhookSignature(body, sig, 'other'), false);
  assert.equal(P.verifyWebhookSignature(Buffer.from('{"a":2}'), sig, 's3cret'), false);
  assert.equal(P.verifyWebhookSignature(body, '', 's3cret'), false);
});
test('payment link payload', () => {
  const p = P.buildPaymentLinkPayload({ orderId: 'PO-7', uid: UID, paise: 149900, nowSec: 1000, siteUrl: 'https://x.in/' });
  assert.equal(p.amount, 149900); assert.equal(p.accept_partial, false); assert.equal(p.expire_by, 1000 + 1800);
  assert.ok(p.reference_id.length <= 40); assert.equal(p.callback_url, 'https://x.in/?cardpay=PO-7'); assert.equal(p.notes.uid, UID);
});

// ---- handler tests with fakes
function fakeDb(data) {
  const sets = {};
  return { sets, ref: path => ({ get: async () => ({ exists: () => path in data, val: () => data[path] }), set: async v => { sets[path] = v; data[path] = v; } }) };
}
function res() { const r = { code: 200, body: null, headers: {} }; r.set = (k, v) => { r.headers[k] = v; }; r.status = c => { r.code = c; return r; }; r.json = b => { r.body = b; return r; }; return r; }
function req(o) { return { method: 'POST', body: o.body, rawBody: o.raw, get: k => (o.headers || {})[k] || (o.headers || {})[k.toLowerCase()] }; }
function mk(data, fetchImpl, tokenImpl) {
  const db = fakeDb(data);
  const calls = [];
  const h = makeHandlers({ db, auth: { verifyIdToken: tokenImpl || (async t => { if (t !== 'good') throw new Error('bad'); return { uid: UID, firebase: { sign_in_provider: 'phone' } }; }) },
    fetchFn: fetchImpl || (async (u, o) => { calls.push([u, o]); return { ok: true, json: async () => ({ short_url: 'https://rzp.io/i/abc' }) }; }),
    keyId: () => 'k', keySecret: () => 's', webhookSecret: () => 'wh', siteUrl: () => 'https://x.in', now: () => 5000000 });
  return { h, db, calls };
}
const good = { headers: { Authorization: 'Bearer good' }, body: { orderId: 'PO-5' } };
const view = { id: 'PO-5', status: 'Processing', total: '₹1,499', t: 1 };

test('createCardPayment: success charges the staff-written total, not anything from the browser', async () => {
  const { h, calls } = mk({ ['customerView/' + UID + '/PO-5']: view });
  const r = res(); await h.createCardPayment(req({ ...good, body: { orderId: 'PO-5', amount: 1 } }), r);
  assert.equal(r.code, 200); assert.equal(r.body.url, 'https://rzp.io/i/abc'); assert.equal(JSON.parse(calls[0][1].body).amount, 149900);
});
test('createCardPayment: refusals', async () => {
  let r;
  r = res(); await mk({}).h.createCardPayment({ ...req(good), method: 'GET' }, r); assert.equal(r.code, 405);
  r = res(); await mk({}).h.createCardPayment(req({ body: good.body }), r); assert.equal(r.code, 401);
  r = res(); await mk({}).h.createCardPayment(req({ headers: { Authorization: 'Bearer nope' }, body: good.body }), r); assert.equal(r.code, 401);
  r = res(); await mk({}, null, async () => ({ uid: UID, firebase: { sign_in_provider: 'anonymous' } })).h.createCardPayment(req(good), r); assert.equal(r.code, 403);
  r = res(); await mk({}).h.createCardPayment(req({ ...good, body: { orderId: '../x' } }), r); assert.equal(r.code, 400);
  r = res(); await mk({}).h.createCardPayment(req(good), r); assert.equal(r.code, 404);
  r = res(); await mk({ ['customerView/' + UID + '/PO-5']: { ...view, status: 'Cancelled' } }).h.createCardPayment(req(good), r); assert.equal(r.code, 409);
  r = res(); await mk({ ['customerView/' + UID + '/PO-5']: { ...view, pay: 'Verified' } }).h.createCardPayment(req(good), r); assert.equal(r.code, 409);
  r = res(); await mk({ ['customerView/' + UID + '/PO-5']: view, ['gatewayPayments/' + UID + '/PO-5']: { status: 'paid' } }).h.createCardPayment(req(good), r); assert.equal(r.code, 409);
  r = res(); await mk({ ['customerView/' + UID + '/PO-5']: { ...view, total: 'ask us' } }).h.createCardPayment(req(good), r); assert.equal(r.code, 422);
  r = res(); await mk({ ['customerView/' + UID + '/PO-5']: view }, async () => ({ ok: false, json: async () => ({}) })).h.createCardPayment(req(good), r); assert.equal(r.code, 502);
  r = res(); await mk({ ['customerView/' + UID + '/PO-5']: view }, async () => ({ ok: true, json: async () => ({ short_url: 'https://evil.example/x' }) })).h.createCardPayment(req(good), r); assert.equal(r.code, 502);
});

function evt(over) {
  const o = Object.assign({ event: 'payment_link.paid', payload: {
    payment_link: { entity: { id: 'plink_1', status: 'paid', notes: { order_id: 'PO-5', uid: UID } } },
    payment: { entity: { id: 'pay_AAA111', status: 'captured', amount: 149900, currency: 'INR', method: 'card' } } } }, over || {});
  const raw = Buffer.from(JSON.stringify(o));
  return { raw, headers: { 'X-Razorpay-Signature': crypto.createHmac('sha256', 'wh').update(raw).digest('hex') } };
}
test('webhook: records a verified payment once', async () => {
  const { h, db } = mk({ ['customerView/' + UID + '/PO-5']: view });
  let r = res(); await h.razorpayWebhook(req(evt()), r);
  assert.equal(r.code, 200); const rec = db.sets['gatewayPayments/' + UID + '/PO-5'];
  assert.equal(rec.status, 'paid'); assert.equal(rec.amount, 1499); assert.equal(rec.flag, undefined);
  r = res(); await h.razorpayWebhook(req(evt()), r); assert.equal(r.body.duplicate, true);                     // retry is harmless
});
test('webhook: flags a different amount and a second payment', async () => {
  const { h, db } = mk({ ['customerView/' + UID + '/PO-5']: { ...view, total: '₹999' } });
  let r = res(); await h.razorpayWebhook(req(evt()), r);
  assert.equal(db.sets['gatewayPayments/' + UID + '/PO-5'].flag, 'amount_mismatch');
  const e2 = evt({ payload: { payment_link: { entity: { id: 'plink_2', status: 'paid', notes: { order_id: 'PO-5', uid: UID } } }, payment: { entity: { id: 'pay_BBB222', status: 'captured', amount: 149900, currency: 'INR', method: 'upi' } } } });
  r = res(); await h.razorpayWebhook(req(e2), r);
  const keys = Object.keys(db.sets); assert.equal(keys.length, 2); assert.match(db.sets[keys[1]].flag, /extra_payment/);
});
test('webhook: bad signature, other events, malformed notes', async () => {
  const { h, db } = mk({});
  let r = res(); const e = evt(); await h.razorpayWebhook(req({ raw: e.raw, headers: { 'X-Razorpay-Signature': 'zz' } }), r); assert.equal(r.code, 400);
  r = res(); await h.razorpayWebhook(req(evt({ event: 'payment.failed' })), r); assert.equal(r.code, 200); assert.equal(r.body.ignored, true);
  r = res(); await h.razorpayWebhook(req(evt({ payload: { payment_link: { entity: { status: 'paid', notes: { order_id: '../../x', uid: UID } } }, payment: { entity: { id: 'p', status: 'captured', amount: 1, currency: 'INR' } } } })), r); assert.equal(r.body.ignored, true);
  assert.equal(Object.keys(db.sets).length, 0);
});
