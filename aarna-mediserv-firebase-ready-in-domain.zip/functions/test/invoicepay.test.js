'use strict';
const test = require('node:test'), assert = require('node:assert');
const crypto = require('crypto');
const P = require('../lib/payments');
const { makeHandlers } = require('../lib/handlers');

const STAFF = 'S'.repeat(28), TOKEN = 'T'.repeat(24);
function fakeDb(data) {
  const sets = {};
  return { sets, ref: path => ({ get: async () => ({ exists: () => path in data, val: () => data[path] }), set: async v => { sets[path] = v; data[path] = v; } }) };
}
function res() { const r = { code: 200, body: null }; r.set = () => {}; r.status = c => { r.code = c; return r; }; r.json = o => { r.body = o; return r; }; return r; }
function req(o) { return { method: 'POST', body: o.body, rawBody: o.raw, get: k => (o.headers || {})[k] || (o.headers || {})[k.toLowerCase()] }; }
function mk(data, fetchImpl, uid) {
  const db = fakeDb(data), calls = [];
  const h = makeHandlers({ db, auth: { verifyIdToken: async t => { if (t !== 'good') throw new Error('bad'); return { uid: uid || STAFF, firebase: { sign_in_provider: 'password' }, email_verified: true }; } },
    fetchFn: fetchImpl || (async (u, o) => { calls.push([u, o]); return { ok: true, json: async () => ({ short_url: 'https://rzp.io/i/inv1' }) }; }),
    keyId: () => 'k', keySecret: () => 's', webhookSecret: () => 'wh', siteUrl: () => 'https://x.in', now: () => 5000000 });
  return { h, db, calls };
}
const staffData = { ['staff/' + STAFF]: true, ['publicInvoices/' + TOKEN]: { no: 'INV-0007', bal: 1250.5, t: 1 } };
const good = { headers: { Authorization: 'Bearer good' }, body: { token: TOKEN } };

test('invoice link payload: amount, expiry, callback and notes', () => {
  const p = P.buildInvoiceLinkPayload({ token: TOKEN, no: 'INV-0007', paise: 125050, nowSec: 1000, siteUrl: 'https://x.in/' });
  assert.equal(p.amount, 125050); assert.equal(p.accept_partial, false); assert.equal(p.expire_by, 1000 + 7 * 86400);
  assert.ok(p.reference_id.length <= 40); assert.equal(p.callback_url, 'https://x.in/?inv=' + TOKEN); assert.equal(p.notes.invoice_token, TOKEN);
});
test('createInvoicePayLink: charges the staff-published balance, not anything from the browser', async () => {
  const { h, calls } = mk(staffData);
  const r = res(); await h.createInvoicePayLink(req({ ...good, body: { token: TOKEN, amount: 1 } }), r);
  assert.equal(r.code, 200); assert.equal(r.body.url, 'https://rzp.io/i/inv1'); assert.equal(JSON.parse(calls[0][1].body).amount, 125050);
});
test('createInvoicePayLink: refusals', async () => {
  let r;
  r = res(); await mk(staffData).h.createInvoicePayLink({ ...req(good), method: 'GET' }, r); assert.equal(r.code, 405);
  r = res(); await mk(staffData).h.createInvoicePayLink(req({ body: good.body }), r); assert.equal(r.code, 401);
  r = res(); await mk(staffData).h.createInvoicePayLink(req({ headers: { Authorization: 'Bearer nope' }, body: good.body }), r); assert.equal(r.code, 401);
  r = res(); await mk(staffData, null, 'C'.repeat(28)).h.createInvoicePayLink(req(good), r); assert.equal(r.code, 403);        // a customer is not staff
  r = res(); await mk(staffData).h.createInvoicePayLink(req({ ...good, body: { token: '../x' } }), r); assert.equal(r.code, 400);
  r = res(); await mk({ ['staff/' + STAFF]: true }).h.createInvoicePayLink(req(good), r); assert.equal(r.code, 404);
  r = res(); await mk({ ['staff/' + STAFF]: true, ['publicInvoices/' + TOKEN]: { no: 'X', bal: 0 } }).h.createInvoicePayLink(req(good), r); assert.equal(r.code, 422);
  r = res(); await mk(staffData, async () => ({ ok: false, json: async () => ({}) })).h.createInvoicePayLink(req(good), r); assert.equal(r.code, 502);
  r = res(); await mk(staffData, async () => ({ ok: true, json: async () => ({ short_url: 'https://evil.example/x' }) })).h.createInvoicePayLink(req(good), r); assert.equal(r.code, 502);
});
function evt() {
  const o = { event: 'payment_link.paid', payload: {
    payment_link: { entity: { id: 'plink_9', status: 'paid', notes: { invoice_token: TOKEN, invoice_no: 'INV-0007' } } },
    payment: { entity: { id: 'pay_ZZZ999', status: 'captured', amount: 125050, currency: 'INR', method: 'upi' } } } };
  const raw = Buffer.from(JSON.stringify(o));
  return { raw, headers: { 'X-Razorpay-Signature': crypto.createHmac('sha256', 'wh').update(raw).digest('hex') } };
}
test('webhook: an invoice payment is recorded once and updates the shared invoice', async () => {
  const { h, db } = mk(staffData);
  let r = res(); await h.razorpayWebhook(req(evt()), r);
  assert.equal(r.code, 200);
  const key = Object.keys(db.sets).find(k => k.startsWith('invoicePay/' + TOKEN + '/'));
  assert.ok(key); assert.equal(db.sets[key].amount, 1250.5); assert.equal(db.sets[key].method, 'upi');
  assert.ok('publicInvoices/' + TOKEN + '/paidAt' in db.sets);
  r = res(); await h.razorpayWebhook(req(evt()), r); assert.equal(r.body.duplicate, true);
});
test('webhook: invoice event with a bad signature or a malformed token is ignored', async () => {
  const { h, db } = mk(staffData);
  const e = evt(); let r = res(); await h.razorpayWebhook(req({ raw: e.raw, headers: { 'X-Razorpay-Signature': 'zz' } }), r); assert.equal(r.code, 400);
  assert.equal(P.extractInvoicePaidEvent({ event: 'payment_link.paid', payload: { payment_link: { entity: { status: 'paid', notes: { invoice_token: '../x' } } }, payment: { entity: { id: 'p', status: 'captured', amount: 100, currency: 'INR' } } } }), null);
  assert.equal(Object.keys(db.sets).length, 0);
});
