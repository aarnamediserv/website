'use strict';
const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret, defineString } = require('firebase-functions/params');
const admin = require('firebase-admin');
const { makeHandlers } = require('./lib/handlers');

admin.initializeApp({ databaseURL: 'https://aarna-mediserv-default-rtdb.firebaseio.com' });

const KEY_ID = defineSecret('RAZORPAY_KEY_ID');
const KEY_SECRET = defineSecret('RAZORPAY_KEY_SECRET');
const WEBHOOK_SECRET = defineSecret('RAZORPAY_WEBHOOK_SECRET');
const SITE_URL = defineString('SITE_URL', { default: 'https://www.aarnamediserv.in' });

const h = makeHandlers({
  db: admin.database(), auth: admin.auth(), fetchFn: (...a) => fetch(...a),
  keyId: () => KEY_ID.value(), keySecret: () => KEY_SECRET.value(), webhookSecret: () => WEBHOOK_SECRET.value(),
  siteUrl: () => SITE_URL.value(), now: () => Date.now()
});

const opts = { region: 'asia-south1', maxInstances: 5, memory: '256MiB', timeoutSeconds: 30 };
exports.createCardPayment = onRequest({ ...opts, secrets: [KEY_ID, KEY_SECRET] }, h.createCardPayment);
exports.createInvoicePayLink = onRequest({ ...opts, secrets: [KEY_ID, KEY_SECRET] }, h.createInvoicePayLink);
exports.razorpayWebhook = onRequest({ ...opts, secrets: [WEBHOOK_SECRET] }, h.razorpayWebhook);
