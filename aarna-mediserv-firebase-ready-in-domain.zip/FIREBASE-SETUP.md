# Firebase setup for AARNA MEDISERV (one-time, about 20 minutes)

Database URL (already set in index.html): https://aarna-mediserv-default-rtdb.firebaseio.com

## How logins work now
- **Staff** sign in at the Admin Login with a Firebase e-mail + password. The server checks the password
  AND that the account is on the staff list. There is no passcode, recovery key or demo account in the page.
- **Customers** sign up with an e-mail + password, must click the confirmation link Firebase e-mails them,
  then log in. Passwords are checked and stored by Google, never by this app.
- Customers can only drop orders / payment notices into a write-only inbox. Only **confirmed** e-mail
  accounts can do this (this stops bots using throw-away addresses).
- Staff devices import them, give the official PO-#### / PAY-# numbers, and publish each order's STATUS
  into that customer's own folder, so customers see live status and can restore their order list on a new phone.
- Destructive actions (the Reset buttons) re-ask for the staff password, checked by the server.

## Steps
1. **Authentication > Sign-in method**: enable **Email/Password** (Anonymous is no longer needed; leave it off).
2. **Authentication > Settings > Authorized domains**: add `www.aarnamediserv.in` and `aarnamediserv.in`
   (confirmation and reset links will not work without this).
3. **Authentication > Templates**: set the sender name and language of the Verify-e-mail and
   Password-reset messages (Settings > Public-facing name). Optionally set your site as the action URL.
4. **Authentication > Users > Add user**: one account per staff member (strong, unique passwords).
5. Copy each staff user's **User UID**.
6. **Realtime Database > Data**: add a top-level node `staff` with one child per UID, value `true`
   (`staff / <UID-1> : true`). Anyone not listed can never open the admin panel or read business data.
7. **Realtime Database > Rules**: paste `database.rules.json` and **Publish**. Then in the **Rules Playground**
   check: an unauthenticated read of `/aarna` is denied; a customer may not read `/inbox`.
8. **Project settings > General > Web API key**: it is already set in `index.html` at
   `AARNA_CLOUD_DEFAULT.apiKey`. Only change it there if you move to a different Firebase project, then re-publish.
9. Google Cloud console > APIs & Services > Credentials > that API key > restrict to HTTP referrers:
   `https://www.aarnamediserv.in/*`, `https://aarnamediserv.in/*`, and while testing
   `https://aarna-mediserv.web.app/*` and `https://aarna-mediserv.firebaseapp.com/*` (remove the last two when done).
   Under API restrictions, keep **Identity Toolkit API** and **Token Service API** allowed.
10. Recommended: turn on **App Check** (reCAPTCHA) and set an e-mail sending quota alert, to limit abuse of
    sign-up / verification e-mails.
11. Take a backup first (Command Center > Data Storage & Sync > Export Backup), then sign in as staff.

## Deploying on Firebase Hosting (this folder is ready: site files are in `public/`)
1. Install the CLI once: `npm install -g firebase-tools`, then `firebase login`.
2. `.firebaserc` already points at the `aarna-mediserv` project (check with `firebase use`).
3. Run `firebase deploy` (publishes `public/`, the security headers and `database.rules.json` together).
   To test first: `firebase hosting:channel:deploy preview`.
4. **Hosting > Add custom domain**: add `www.aarnamediserv.in`, and add `aarnamediserv.in` as a
   **redirect to www**. HTTPS is automatic. (firebase.json cannot redirect by host name; the domain settings do it.)
5. Only the files inside `public/` go online. Nothing else in this folder is published.
6. `public/sw.js` makes the site installable and lets it open offline. If you edit any shell file
   (index.html, manifest, icons), change the `CACHE` name inside sw.js.
7. The price-list readers (Excel, Word, PDF, OCR) and the Orders Excel export are now served from this site's own
   `public/vendor/` folder (versions and SHA-256 hashes in `vendor/SOURCES.txt`). No CDN is contacted, so they also work
   offline after first use. The three.js 3D viewer is embedded in `index.html`.

## Content-Security-Policy (Report-Only, added)
`firebase.json` now sends a `Content-Security-Policy-Report-Only` header. It blocks nothing; it only makes the browser
log what a strict policy WOULD block. To read the log: open the live site, press F12, Console, and look for messages starting
"[Report Only] Refused to ...". Use the site normally for a week: customer login, Google sign-in (if on), phone sign-in
(if on), placing an order, card payment (if on), staff login, price-list import (Excel, Word, PDF, photo), 3D model.
If the console stays free of these messages, change the header name from `Content-Security-Policy-Report-Only` to
`Content-Security-Policy` in `firebase.json` and run `firebase deploy --only hosting`. If something legitimate is listed,
add that host to the matching directive first. The policy still allows inline scripts and styles (the app is one big
file), so it limits where code can load from and where data can be sent, not inline injection itself.
Violations are not collected centrally (that needs a reporting endpoint); they appear only in each browser's console.

## Google sign-in for customers (added)
Customers get a "Continue with Google" button in the Customer Login window. It creates the account on first use, and Google
confirms the e-mail address, so no confirmation e-mail is needed. Staff still sign in with e-mail + password only (the
Reset buttons re-ask the staff password). The button stays hidden until step 4 is done; e-mail + password keeps working.
1. **Authentication > Sign-in method > Add new provider > Google > Enable**, set the public-facing name and support
   e-mail, then Save.
2. Open the Google provider again > **Web SDK configuration** > copy the **Web client ID**
   (looks like `1234567890-abc123.apps.googleusercontent.com`).
3. Google Cloud console > APIs & Services > Credentials > open that **Web client** (named "Web client (auto created by
   Google Service)") > **Authorized JavaScript origins**, add: `https://www.aarnamediserv.in`,
   `https://aarnamediserv.in`, and while testing `https://aarna-mediserv.web.app`,
   `https://aarna-mediserv.firebaseapp.com`, `http://localhost:5000`. Leave redirect URIs as they are. Save (can take a few minutes).
   Also check APIs & Services > OAuth consent screen is set to **Published / In production**, or only test users can sign in.
   On the OAuth consent screen, set **Application home page** to `https://www.aarnamediserv.in` and
   **Privacy policy link** to `https://www.aarnamediserv.in/privacy` (this page ships in `public/privacy.html`).
4. In `public/index.html`, find `AARNA_GOOGLE_CLIENT_ID = ''` and paste the Web client ID between the quotes. Redeploy.
5. Test on the preview/live site: open Customer Login, tap Continue with Google, then place a test order and confirm it
   reaches the staff inbox. No change to `database.rules.json` is needed (Google accounts arrive e-mail-verified).
- If a customer already signed up with e-mail + password using the same address, Google sign-in may be refused with a
  message asking them to use their password.

## Phone sign-in for customers (added, switched off until you enable it)
Customers get a "Log in with mobile number (SMS code)" link in the Customer Login window. Firebase's sign-in script and
Google's invisible reCAPTCHA load only when a customer taps that link. A 10-digit number is treated as an Indian (+91) number.
The link stays hidden until step 4 is done. Phone customers have no e-mail address; they are a separate account from any
e-mail or Google account the same person may have.
1. **Upgrade the project to the Blaze (pay-as-you-go) plan** (Firebase console > Usage and billing). Phone sign-in does not
   work on the free Spark plan. Add a budget alert (Google Cloud console > Billing > Budgets) so SMS costs cannot surprise you.
2. **Authentication > Sign-in method > Add new provider > Phone > Enable**.
3. **Authentication > Settings > SMS region policy**: allow **India (+91)** (and any other country you serve). Under
   Authentication > Sign-in method > Phone you can also add **test phone numbers** with fixed codes, which cost nothing.
   Check Authentication > Settings > Authorized domains lists your live and `web.app` domains.
4. In `public/index.html`, change `AARNA_PHONE_AUTH = false` to `true`, then run `firebase deploy`
   (this also publishes the updated `database.rules.json`).
5. Test with a test phone number first, then once with your own number. Place a test order and confirm it reaches the staff inbox.
- **Database rules changed:** order and payment uploads are now accepted from customers signed in by phone as well as from
  e-mail-verified customers. Re-deploying rules is required for phone customers to be able to submit.
- If your API key is restricted (step 9 above), keep Identity Toolkit API and Token Service API allowed. Phone sign-in also
  uses Google reCAPTCHA, which needs no extra key.
- Abuse protection: reCAPTCHA is built in, and Firebase limits SMS per number and per IP. You can lower the daily SMS
  quota in Google Cloud console > APIs & Services > Identity Toolkit API > Quotas.

## Tighter database rules (added)
Customer uploads to `/inbox` are now accepted only from phone-verified customers, or from e-mail/password or Google customers
whose e-mail is verified. Anonymous or other sign-in types are refused outright, and an empty payload is refused. Everything
else is unchanged. Publish with `firebase deploy` (or `firebase deploy --only database`).
After deploying, check it in **Realtime Database > Rules > Rules Playground** (simulator), using your project's data:
- Unauthenticated read of `/aarna`, `/inbox` or `/staff`: **denied**.
- A signed-in verified customer **writes** `/inbox/<their own uid>/<valid id>` with a valid payload: **allowed**.
  The same write to a different uid, or by an unverified e-mail account: **denied**.
- A customer **reads** `/inbox`: **denied**. Reads `/receipts/<own uid>` and `/customerView/<own uid>`: **allowed**; another uid: **denied**.
- A staff user (uid listed under `/staff`) reads and writes `/aarna`: **allowed**; a normal customer: **denied**.
I could not run Firebase's rules emulator in my working environment, so these checks have not been run for you. Please run them once.

## Automatic backups (Realtime Database)
Firebase has a built-in daily backup of your data and rules (JSON, to a Cloud Storage bucket). It needs the **Blaze plan**
(which you need for phone sign-in anyway) and costs nothing extra beyond normal Cloud Storage charges for the backup files.
1. Firebase console > **Realtime Database > Backups** tab, then follow the setup wizard.
2. Choose a bucket location close to you (for example Mumbai, `asia-south1`) and turn on the **30-day lifecycle** option,
   so old backups delete themselves.
3. Use **Start a manual backup** once and confirm a file appears in the Backups tab.
4. Restoring: download the backup file from the Backups tab or the Cloud Storage bucket, then follow Firebase's restore
   steps in the Realtime Database Data and Settings tabs (see "Automated Backups" in Firebase's Realtime Database documentation).
   Practice this once on a test project before you ever need it.
5. Treat the backup bucket as sensitive: it contains customer orders. Keep access to the Google Cloud project limited to people who need it.
Staff can also still use the app's own **Export backup** in the Command Center (Data Storage & Sync) for an extra copy on your computer.

## Orders export to Excel / CSV (added)
Admin Panel > **Orders** has From / To dates, a status filter and two buttons: **Export Excel** and **Export CSV**.
- Excel file: sheets **Orders**, **Payments** (for the exported orders) and **Summary** (count and total per status).
- CSV file: the Orders sheet only, opens correctly in Excel (UTF-8) with formula-injection protection.
- Amounts are exported as numbers (INR). Customer phone, address and form answers are deliberately **not** included,
  to keep exported files low-risk. The Excel export needs an internet connection the first time (it loads the same
  spreadsheet library as the price-list import).

## Privacy policy and card form (changed)
- **Privacy Policy:** a "Privacy Policy" tab was added to the site, plus a standalone page at `/privacy`
  (file `public/privacy.html`, also listed in the sitemap). It is a plain-language draft based on what the app actually does.
  Please read it, change anything that is not true for your business (for example how long you keep records),
  and ideally have a lawyer review it. If you edit the text, change it in both `index.html` (section `id="privacy"`) and `privacy.html`.
- **Credit Card Payment form removed:** it asked for card number and CVV but never charged anything. Customers now pay by UPI,
  with a line telling them to call for other ways to pay. Staff can still record card/cash/bank payments manually in the Admin Panel.
  Real card payments are provided by the Razorpay section below (hosted checkout, never your own card fields).

## Card payments with Razorpay (added, switched off until you set it up)
Customers can pay by debit/credit card (Visa, Mastercard, RuPay), netbanking or UPI on **Razorpay's own secure page**. Card
details are never entered on your website. Visa and Mastercard are card networks, not payment companies, so a payment gateway
is needed; Razorpay is the one built in.
**How it works:** the customer taps *Pay Securely Online* on the Payments tab. A small server function (in `functions/`) checks
their login, reads the order total **that staff wrote** (never a price sent from the browser), creates a 30-minute Razorpay
payment link and sends the customer there. When Razorpay confirms the payment, a second function checks Razorpay's signature
and records it. The customer sees "Payment received", and staff see it in **Admin Panel > Payments > Online card payments**.
Only orders that staff have confirmed (order number starting `PO-`) can be paid online.
**Setup (do in Razorpay Test Mode first):**
1. Create a Razorpay account (razorpay.com). Live payments need their business verification (KYC) first; Test Mode works straight away.
2. Razorpay Dashboard > Account & Settings > API keys > generate **Test** keys (a Key ID and a Key Secret).
3. In this folder run `cd functions && npm install && cd ..`, then set the three secrets (each command asks you to paste the value):
   `firebase functions:secrets:set RAZORPAY_KEY_ID`, `firebase functions:secrets:set RAZORPAY_KEY_SECRET`, and
   `firebase functions:secrets:set RAZORPAY_WEBHOOK_SECRET` (for this one, invent a long random password and keep a copy for step 5).
4. Run `firebase deploy`. This publishes the site, rules and the two functions (Blaze plan required; the first deploy may ask to
   enable some Google Cloud services, answer yes). If the CLI complains about the Node version, update firebase-tools (`npm i -g firebase-tools`).
5. Razorpay Dashboard > Account & Settings > Webhooks > Add new webhook: URL `https://www.aarnamediserv.in/api/razorpayWebhook`
   (while testing on the preview domain use `https://aarna-mediserv.web.app/api/razorpayWebhook`), Secret = the same value as
   `RAZORPAY_WEBHOOK_SECRET`, tick only the event **payment_link.paid**.
6. In `public/index.html` set `AARNA_CARD_PAY = true`, then `firebase deploy --only hosting`.
7. Test: log in as a customer, have staff confirm an order (it gets a PO- number), tap *Pay Securely Online*, and pay with one of
   the test cards in Razorpay's documentation. Check the customer sees "Payment received" and staff see the row.
8. **Going live:** generate **Live** keys, re-run the two `functions:secrets:set` commands for the key ID and secret, create the
   webhook again in Razorpay's **Live** mode (same URL, new secret value, update `RAZORPAY_WEBHOOK_SECRET` to match), and run
   `firebase deploy --only functions`.
**Good to know:**
- Staff still need to record a received online payment under Payments with method "Credit Card", so the "Verified Received"
  totals match. The table shows a **CHECK** note if the amount paid differs from the order total, or if an order was paid twice.
- Refunds are done in the Razorpay dashboard. Razorpay charges a fee per transaction (see their current pricing; GST applies to the fee).
- Orders whose total is not a plain rupee amount (for example "Quote on request") cannot be paid online; the customer is told to contact you.
- Functions run in Mumbai (`asia-south1`). Light use stays within Google's free allowance; Razorpay's own fees are the main cost.
- I tested the logic with automated tests and a simulated Razorpay and database. It has not been run against real Razorpay or
  your live Firebase project, so complete step 7 in Test Mode before taking real money.
- The privacy policy now mentions Razorpay. Please re-read it.

## Before going live (checklist)
- [ ] Step 9 above is done: the API key is restricted to your two web addresses.
- [ ] `database.rules.json` is published (step 7) and the Rules Playground checks pass.
- [ ] Every staff member has a `staff/<UID>: true` entry (step 6).
- [ ] Scan the UPI QR on the Payments tab with a real UPI app (GPay / PhonePe / Paytm) and confirm it shows
      `9413962898@upi` and AARNA MEDISERV. The QR is drawn by the page itself; there is no image file to upload.
- [ ] Google sign-in (if used): Web client ID pasted, authorized origins added, consent screen published, one test login done.
- [ ] Phone sign-in (if used): Blaze plan on, Phone provider enabled, India allowed, AARNA_PHONE_AUTH = true, rules deployed, test number tried.
- [ ] Rules Playground checks done, Backups tab set up with a manual test backup, one Excel export tried.
- [ ] Privacy policy read and approved; consent screen links set.
- [ ] Card payments (if used): secrets set, webhook added, AARNA_CARD_PAY = true, Test Mode payment worked end to end, then Live keys and live webhook set.
- [ ] On the preview channel (`firebase hosting:channel:deploy preview`), import a sample price list of each kind (Excel, Word,
      PDF and a photo for OCR). The OCR language file is `vendor/tesseract/lang/eng.traineddata.gz`; if OCR fails on the live
      host but worked locally, the host is altering that file's encoding (check its response headers).
- [ ] Console free of "[Report Only]" messages during a normal week, then switch the CSP header to enforcing (see above).

## What changed for existing users
- Old demo customer sign-ups cannot log in any more (their stored passwords are wiped from the device).
  Customers must sign up again with an **e-mail address** (phone-number sign-up is not supported).
- The on-screen "Demo Mode" codes are gone. There is no second factor yet (see below).
- Add or remove staff in the Firebase console. To lock a staff member out immediately, delete their
  `staff/<UID>` entry (access to business data stops at once) and disable the user.

## Limits you should know
- Two-step verification (SMS / authenticator app) for staff needs Firebase "Identity Platform" (paid plan).
  Not included; use long unique staff passwords meanwhile.
- The admin screen lock is a convenience. The real protection is the database rules: a person who forces
  the screen open still cannot download business data unless signed in as listed staff.
- A staff device keeps a copy of business data on that device. Use dedicated staff devices / browser profiles.
- Customers learn their official number, and later status changes, within about a minute of a staff sync.
- Uploaded photos / prescriptions are not sent through the inbox.


## Command Center: publishing site settings

The Command Center (Admin Panel -> Command Center) can publish a small, public settings object
(announcement bar, maintenance mode, page text edits, SEO title/description, feature switches and
branding) to `/siteConfig` in your Realtime Database. The public site reads it on every load.

1. Deploy the updated rules once (they add a public-read, staff-write `siteConfig` path):

       firebase deploy --only database

2. In the Command Center press **Publish to live site**. Until the rules are deployed, publishing
   fails with "Permission denied" and nothing changes for visitors.

`siteConfig` is readable by anyone, so never put private data in it. The Command Center only
publishes visitor-facing settings; orders, payments, customers and roles are never published.

## Invoice Plus: customer invoice link and online pay link

Everything in Invoice Plus (logo / signature / stamp, watermark, A4 / A5 / 80 mm paper, presets, notes,
per-line discount, transport details, GSTIN check, linked credit notes, financial-year numbers, part
payments, late fee, lock + history, duplicate, bulk print) works without any setup. Only the two online
features below need the backend deployed.

1. **Customer invoice link** (`yoursite/?inv=<long random code>`). Staff press *Create customer link* under
   the invoice preview. This copies the printed invoice to `/publicInvoices/<code>`, which anyone holding the
   code can read (nothing else under `/publicInvoices` can be listed). Deploy the updated rules once:

       firebase deploy --only database

   *Stop sharing* deletes the copy. After you record a payment or edit the invoice, press *Update link*.

2. **Online pay link** (Razorpay). Needs the card-payment setup above (`AARNA_CARD_PAY = true`, Razorpay keys,
   webhook) plus the new function and hosting rewrite (`/api/createInvoicePayLink`):

       firebase deploy --only functions,hosting

   The link is for the balance due at the moment you create it (valid 7 days). The Razorpay webhook records
   the payment under `/invoicePay/<code>` (staff-read only); the invoice picks it up automatically within a
   minute of being opened, or when you press *Check online payments*, and adds it to the payments list.
   Create a new pay link after you record any other payment so the amount stays correct.

Tests for the new function: `cd functions && npm test`.

## Customer messages ("Send Us a Message")

The Contact tab message card now works like the appointment card. Logged-in customers send messages through the same write-only inbox (kind `msg`), and staff import them on sync into Command Center > Customers > Messages. Anyone else gets the message saved on their device plus a "Send on WhatsApp" button.

**You must publish the updated `database.rules.json`** (it now allows `k: 'msg'` in the inbox), otherwise customer messages are rejected by Firebase:

    firebase deploy --only database
